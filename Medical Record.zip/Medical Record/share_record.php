<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $file = $_FILES['file'];
    $shareOption = $_POST['shareOption'];

    // Handle file upload
    $uploadDir = 'uploads/';
    if (!file_exists($uploadDir)) {
        mkdir($uploadDir, 0777, true);
    }

    $targetFile = $uploadDir . basename($file["name"]);
    move_uploaded_file($file["tmp_name"], $targetFile);

    if ($shareOption === 'email') {
        // Send email (you'll need to set up mail sending)
        mail($email, "Your Shared Record", "You have received a record. Download it from: " . $targetFile);
    } else {
        // Share via link (you can generate a public URL or token)
        $shareableLink = "http://yourwebsite.com/" . $targetFile;
        // For demonstration, we're just echoing the link here
        echo "Shareable link: <a href='$shareableLink'>$shareableLink</a>";
    }

    echo "File shared successfully!";
} else {
    echo "Invalid request method.";
}
?>
