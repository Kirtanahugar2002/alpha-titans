// Navigation Menu Toggle (for mobile)
const navToggle = document.querySelector('nav button');
const navLinks = document.querySelector('nav .md\\:hidden');

if (navToggle) {
    navToggle.addEventListener('click', () => {
        navLinks.classList.toggle('hidden');
    });
}

// Upload Section Drag and Drop
const uploadSection = document.querySelector('.upload-section');

if (uploadSection) {
    uploadSection.addEventListener('dragover', (event) => {
        event.preventDefault();
        uploadSection.classList.add('border-blue-500');
    });

    uploadSection.addEventListener('dragleave', () => {
        uploadSection.classList.remove('border-blue-500');
    });

    uploadSection.addEventListener('drop', (event) => {
        event.preventDefault();
        uploadSection.classList.remove('border-blue-500');
        const files = event.dataTransfer.files;
        handleFileUpload(files);
    });

    uploadSection.addEventListener('click', () => {
        const fileInput = document.createElement('input');
        fileInput.type = 'file';
        fileInput.accept = '.pdf,.jpg,.png';
        fileInput.multiple = true;

        fileInput.onchange = (event) => {
            const files = event.target.files;
            handleFileUpload(files);
        };

        fileInput.click();
    });
}

// File Upload Handling
function handleFileUpload(files) {
    if (files.length > 0) {
        alert(`${files.length} file(s) uploaded successfully!`);
        console.log('Uploaded files:', files);
    } else {
        alert('No files selected!');
    }
}

// Quick Actions
const quickActions = document.querySelectorAll('.quick-actions div');

quickActions.forEach((action) => {
    action.addEventListener('click', () => {
        const actionName = action.querySelector('h3').innerText;
        alert(`Quick Action: ${actionName}`);
    });
});

// Record Card Actions
const recordCards = document.querySelectorAll('.card');

recordCards.forEach((card) => {
    const shareButton = card.querySelector('.bi-share');
    const downloadButton = card.querySelector('.bi-download');

    shareButton?.addEventListener('click', () => {
        alert('Sharing this record...');
    });

    downloadButton?.addEventListener('click', () => {
        alert('Downloading this record...');
    });
});

// Button: "Get Started"
const getStartedButton = document.querySelector('header button');
if (getStartedButton) {
    getStartedButton.addEventListener('click', () => {
        alert('Redirecting to the registration page...');
        // Example redirect (update with your URL)
        window.location.href = '/register';
    });
}

// Button: "View All Records"
const viewAllRecordsLink = document.querySelector('section a.text-blue-600');
if (viewAllRecordsLink) {
    viewAllRecordsLink.addEventListener('click', (event) => {
        event.preventDefault();
        alert('Navigating to the full records page...');
        // Example redirect (update with your URL)
        window.location.href = '/records';
    });
}

// Dynamic Record Addition Example (optional)
function addNewRecord(recordName, fileType, uploadDate, fileSize) {
    const recordsContainer = document.querySelector('.grid.grid-cols-1');
    if (!recordsContainer) return;

    const recordCard = document.createElement('div');
    recordCard.className = 'card bg-white p-4 rounded-lg shadow-sm transition-all';
    recordCard.innerHTML = `
        <div class="flex items-center">
            <i class="bi bi-file-earmark-medical text-blue-600 text-2xl"></i>
            <div class="ml-4">
                <h3 class="text-lg font-semibold">${recordName}</h3>
                <p class="text-sm text-gray-500">Uploaded: ${uploadDate}</p>
            </div>
        </div>
        <div class="flex justify-between items-center mt-4">
            <span class="text-sm text-gray-500">${fileType} • ${fileSize}</span>
            <div class="flex space-x-3">
                <button class="text-gray-600 hover:text-blue-600">
                    <i class="bi bi-share"></i>
                </button>
                <button class="text-gray-600 hover:text-blue-600">
                    <i class="bi bi-download"></i>
                </button>
            </div>
        </div>
    `;

    recordsContainer.appendChild(recordCard);

    // Reattach event listeners for new record buttons
    const shareButton = recordCard.querySelector('.bi-share');
    const downloadButton = recordCard.querySelector('.bi-download');

    shareButton.addEventListener('click', () => {
        alert(`Sharing record: ${recordName}`);
    });

    downloadButton.addEventListener('click', () => {
        alert(`Downloading record: ${recordName}`);
    });
}

// Example: Add a new record dynamically
addNewRecord('X-Ray Report', 'PDF', 'Nov 26, 2023', '2.4 MB');
