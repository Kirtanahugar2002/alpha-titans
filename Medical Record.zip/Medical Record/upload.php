<?php
session_start();

$server = "localhost"; 
$username = "root";  // Replace with your database username
$password = "";  // Replace with your database password
$dbname = "records";  // Database name

// Create connection
$conn = new mysqli($server, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Ensure the user is logged in
if (!isset($_SESSION['user_id'])) {
    die("<script>
        alert('You must be logged in to upload');
        window.location.href = 'login.html'; // Redirect to forgot password page
    </script>");
}

// Check if the form is submitted and the file is uploaded
if (isset($_FILES['medical_file'])) {
    $file_name = $_FILES['medical_file']['name'];
    $file_tmp = $_FILES['medical_file']['tmp_name'];
    $file_size = $_FILES['medical_file']['size'];
    $file_error = $_FILES['medical_file']['error'];

    // Check for file upload errors
    if ($file_error === 0) {
        // Define upload directory and file path
        $upload_dir = "uploads/";
        $file_path = $upload_dir . basename($file_name);

        // Check file size (for example, 10MB max)
        if ($file_size > 10485760) {
            die("File size is too large. Maximum size is 10MB.");
        }

        // Move the uploaded file to the uploads directory
        if (move_uploaded_file($file_tmp, $file_path)) {
            // Get the user ID from the session (make sure user is logged in)
            $user_id = $_SESSION['user_id'];

            // Prepare the SQL statement
            $stmt = $conn->prepare("INSERT INTO medicalrecords (user_id, file_name, file_path) VALUES (?, ?, ?)");

            // Check if the statement preparation is successful
            if ($stmt === false) {
                die('MySQL prepare error: ' . $conn->error);
            }

            // Bind parameters: "iss" means integer, string, string
            if (!$stmt->bind_param("iss", $user_id, $file_name, $file_path)) {
                die('Binding parameters failed: ' . $stmt->error);
            }

            // Execute the query
            if ($stmt->execute()) {
                // Show success pop-up message and redirect after 3 seconds
                echo '<script type="text/javascript">
                        alert("Your file has been uploaded successfully!");
                        window.location.href = "upload.html"; // Redirect to the upload page
                      </script>';
                exit;
            } else {
                // Handle any errors during execution
                echo "Error uploading file to the database: " . $stmt->error;
            }

            // Close the prepared statement
            $stmt->close();
        } else {
            // File upload failed
            echo "There was an error uploading your file.";
        }
    } else {
        // Handle any file upload errors
        echo "Error during file upload.";
    }
} else {
    // No file selected
    echo "No file selected for upload.";
}

// Close the database connection
$conn->close();
?>