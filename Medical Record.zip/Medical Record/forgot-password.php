<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];

    // Validate email format
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        die("Invalid email format.");
    }

    // Connect to the database
    $conn = new mysqli("localhost", "root", "", "records");  // Update with your database credentials
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Check if the email exists in the database
    $stmt = $conn->prepare("SELECT id, email, security_question FROM Users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        $user_id = $user['id'];
        $security_question = $user['security_question'];

        // Store user_id in session for the next step
        $_SESSION['reset_user_id'] = $user_id;

        // Show the security question to the user
        echo '<form action="validate-security.php" method="POST">';
        echo '<label>' . $security_question . '</label><br>';
        echo '<input type="text" name="security_answer" required><br>';
        echo '<button type="submit">Submit</button>';
        echo '</form>';
    } else {
        echo "No user found with that email.";
    }

    $stmt->close();
    $
