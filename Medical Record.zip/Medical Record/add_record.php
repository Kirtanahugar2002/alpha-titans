<?php
session_start();

// Database connection
$server = "localhost";
$username = "root";
$password = "";
$dbname = "records";

$conn = new mysqli($server, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Ensure the user is logged in
if (!isset($_SESSION['user_id'])) {
    die("You must be logged in to upload records.");
}

// Check if the form is submitted and the file is uploaded
if (isset($_FILES['medical_file'])) {
    $file_name = $_FILES['medical_file']['name'];
    $file_tmp = $_FILES['medical_file']['tmp_name'];
    $file_size = $_FILES['medical_file']['size'];
    $file_error = $_FILES['medical_file']['error'];

    // Validate the file upload
    if ($file_error === 0) {
        $upload_dir = "uploads/";
        $file_path = $upload_dir . basename($file_name);

        // Check file size (10MB max)
        if ($file_size > 10485760) {
            echo "<script>alert('File size exceeds the maximum limit of 10MB.'); window.location.href='upload.html';</script>";
            exit;
        }

        // Move the uploaded file to the uploads directory
        if (move_uploaded_file($file_tmp, $file_path)) {
            $user_id = $_SESSION['user_id'];

            // Check if the user has a valid security setup
            $stmt = $conn->prepare("SELECT security_question, security_answer FROM Users WHERE id = ?");
            $stmt->bind_param("i", $user_id);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                $user = $result->fetch_assoc();
                if (empty($user['security_question']) || empty($user['security_answer'])) {
                    echo "<script>alert('Please set up your security question and answer before uploading files.'); window.location.href='manage-security.html';</script>";
                    exit;
                }
            } else {
                echo "<script>alert('Invalid user session. Please log in again.'); window.location.href='login.html';</script>";
                exit;
            }

            // Insert file record into the database
            $stmt = $conn->prepare("INSERT INTO medicalrecords (user_id, file_name, file_path) VALUES (?, ?, ?)");
            if ($stmt === false) {
                die("MySQL prepare error: " . $conn->error);
            }

            if (!$stmt->bind_param("iss", $user_id, $file_name, $file_path)) {
                die("Binding parameters failed: " . $stmt->error);
            }

            if ($stmt->execute()) {
                echo "<script>alert('File uploaded successfully.'); window.location.href='upload.html';</script>";
            } else {
                echo "<script>alert('Failed to upload the file. Please try again.'); window.location.href='upload.html';</script>";
            }

            $stmt->close();
        } else {
            echo "<script>alert('Failed to upload the file. Please try again.'); window.location.href='upload.html';</script>";
        }
    } else {
        echo "<script>alert('Error during file upload. Please try again.'); window.location.href='upload.html';</script>";
    }
} else {
    echo "<script>alert('No file selected for upload. Please choose a file.'); window.location.href='upload.html';</script>";
}

// Close the database connection
$conn->close();
?>
