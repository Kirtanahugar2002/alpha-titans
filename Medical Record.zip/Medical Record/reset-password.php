<?php
// Assume you have a database connection here
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];

    // Validate email format
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        die("Invalid email format.");
    }

    // Check if the email exists in the database
    $conn = new mysqli("localhost", "root", "", "records");  // Update with your database credentials
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $stmt = $conn->prepare("SELECT id, email FROM Users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        $user_id = $user['id'];

        // Generate a unique reset token (using a simple random string for demonstration)
        $reset_token = bin2hex(random_bytes(16));

        // Store the token in the database (e.g., in a password_reset table)
        $stmt = $conn->prepare("INSERT INTO password_resets (user_id, token, created_at) VALUES (?, ?, NOW())");
        $stmt->bind_param("is", $user_id, $reset_token);
        $stmt->execute();

        // Send the reset link via email (example with PHPMailer or other mail libraries)
        $reset_link = "https://yourdomain.com/reset-password.php?token=" . $reset_token;

        // Send email (you can replace the below line with a mail function or PHPMailer for actual emailing)
        echo "Password reset link: " . $reset_link;

        // In real use, you'd send the email to the user's email address
    } else {
        echo "No user found with that email.";
    }

    $stmt->close();
    $conn->close();
}
?>
