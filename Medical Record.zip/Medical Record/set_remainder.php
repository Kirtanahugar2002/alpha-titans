<?php
session_start();
$server = "localhost";
$username = "root";
$password = "";
$dbname = "records";

// Connect to the database
$conn = new mysqli($server, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Ensure user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.html");
    exit;
}

$user_id = $_SESSION['user_id'];

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = htmlspecialchars($_POST['title']);
    $description = htmlspecialchars($_POST['description']);
    $reminder_date = htmlspecialchars($_POST['reminder_date']);

    if (!empty($title) && !empty($reminder_date)) {
        $stmt = $conn->prepare("INSERT INTO reminders (user_id, title, description, reminder_date) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("isss", $user_id, $title, $description, $reminder_date);

        if ($stmt->execute()) {
            $_SESSION['message'] = "Reminder set successfully!";
        } else {
            $_SESSION['message'] = "Error: Could not set reminder.";
        }
        $stmt->close();
    } else {
        $_SESSION['message'] = "Title and Reminder Date are required.";
    }
    header("Location: set_reminder.php");
    exit;
}

// Fetch reminders for the logged-in user
$reminders = [];
$stmt = $conn->prepare("SELECT * FROM reminders WHERE user_id = ? ORDER BY reminder_date ASC");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    $reminders[] = $row;
}
$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Set Reminder</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body class="bg-gray-100 text-gray-700">
    <nav class="bg-white shadow">
        <div class="container mx-auto px-4 py-4 flex justify-between items-center">
            <h1 class="text-xl font-bold text-blue-600">Set Reminder</h1>
            <a href="dashboard.html" class="text-blue-600 hover:underline">Dashboard</a>
        </div>
    </nav>

    <div class="container mx-auto px-4 py-10">
        <h2 class="text-2xl font-bold mb-6">Create a Reminder</h2>
        <form action="set_reminder.php" method="POST" class="bg-white p-6 shadow rounded">
            <label for="title" class="block text-lg font-bold mb-2">Title</label>
            <input type="text" name="title" id="title" class="w-full p-2 mb-4 border rounded" required>

            <label for="description" class="block text-lg font-bold mb-2">Description</label>
            <textarea name="description" id="description" class="w-full p-2 mb-4 border rounded"></textarea>

            <label for="reminder_date" class="block text-lg font-bold mb-2">Reminder Date & Time</label>
            <input type="datetime-local" name="reminder_date" id="reminder_date" class="w-full p-2 mb-4 border rounded" required>

            <button type="submit" class="bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700">Set Reminder</button>
        </form>

        <h2 class="text-2xl font-bold mt-10 mb-6">Your Reminders</h2>
        <div class="grid gap-4">
            <?php foreach ($reminders as $reminder): ?>
                <div class="bg-white p-4 shadow rounded">
                    <h3 class="text-lg font-bold text-blue-600"><?php echo htmlspecialchars($reminder['title']); ?></h3>
                    <p class="text-gray-600"><?php echo htmlspecialchars($reminder['description']); ?></p>
                    <p class="text-gray-500 mt-2">Reminder Date: <?php echo htmlspecialchars($reminder['reminder_date']); ?></p>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <?php if (isset($_SESSION['message'])): ?>
        <script>
            Swal.fire({
                title: 'Notification',
                text: "<?php echo addslashes($_SESSION['message']); ?>",
                icon: 'success',
                confirmButtonText: 'OK'
            });
        </script>
        <?php unset($_SESSION['message']); ?>
    <?php endif; ?>
</body>
</html>
