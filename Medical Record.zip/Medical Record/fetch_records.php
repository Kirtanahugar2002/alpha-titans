<?php
session_start();

$server = "localhost";
$username = "root"; 
$password = "";
$dbname = "records";  

$conn = new mysqli($server, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (!isset($_SESSION['user_id'])) {
    echo json_encode([]); // Return empty array if not logged in
    exit;
}

$user_id = $_SESSION['user_id'];

$query = "SELECT * FROM medicalrecords WHERE user_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

$records = [];
while ($row = $result->fetch_assoc()) {
    $records[] = $row;
}

$stmt->close();
$conn->close();

// Return records as JSON
echo json_encode($records);
?>