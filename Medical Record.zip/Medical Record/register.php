<?php
session_start();
require 'db.php'; // Include your database connection file

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = htmlspecialchars($_POST['username']);
    $email = htmlspecialchars($_POST['email']);
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT); // Hash the password
    $security_question = htmlspecialchars($_POST['security_question']);
    $security_answer = htmlspecialchars($_POST['security_answer']);

    try {
        // Check if the email already exists
        $stmt = $conn->prepare("SELECT * FROM Users WHERE email = :email");
        $stmt->bindParam(':email', $email);
        $stmt->execute();

        if ($stmt->rowCount() > 0) {
            $_SESSION['message'] = "Email is already registered.";
            header("Location: register.html");
            exit;
        }

        // Insert the new user into the database
        $stmt = $conn->prepare("INSERT INTO Users (username, email, password, security_question, security_answer) 
                                VALUES (:username, :email, :password, :security_question, :security_answer)");
        $stmt->bindParam(':username', $username);
        $stmt->bindParam(':email', $email);
        $stmt->bindParam(':password', $password);
        $stmt->bindParam(':security_question', $security_question);
        $stmt->bindParam(':security_answer', $security_answer);

        if ($stmt->execute()) {
            $_SESSION['registration_success'] = true;
            header("Location: login.html"); // Redirect to login page
            exit;
        } else {
            $_SESSION['message'] = "Error: Could not register user.";
        }
    } catch (PDOException $e) {
        die("Database error: " . $e->getMessage());
    }
} else {
    echo "Invalid request method.";
}
?>
