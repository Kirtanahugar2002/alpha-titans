<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $security_answer = trim($_POST['security_answer']);

    // Validate if user ID exists in the session
    if (!isset($_SESSION['reset_user_id'])) {
        die("Invalid request.");
    }

    $user_id = $_SESSION['reset_user_id'];

    // Connect to the database
    $conn = new mysqli("localhost", "root", "", "records");  // Update with your database credentials
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Check if the answer matches the stored security answer
    $stmt = $conn->prepare("SELECT security_answer FROM Users WHERE id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        if (password_verify($security_answer, $user['security_answer'])) {
            // Security answer is correct, generate reset link
            $reset_token = bin2hex(random_bytes(16));
            $stmt = $conn->prepare("INSERT INTO password_resets (user_id, token, created_at) VALUES (?, ?, NOW())");
            $stmt->bind_param("is", $user_id, $reset_token);
            $stmt->execute();

            $reset_link = "https://yourdomain.com/reset-password.php?token=" . $reset_token;

            echo "Password reset link: " . $reset_link;

            // In a real-world scenario, send the reset link via email
        } else {
            echo "Incorrect security answer.";
        }
    } else {
        echo "Invalid user.";
    }

    $stmt->close();
    $conn->close();
}
?>
