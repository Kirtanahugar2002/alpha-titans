<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $password = $_POST['password'];
    $security_question = $_POST['security_question'];
    $security_answer = $_POST['security_answer'];

    // Connect to database
    $conn = new mysqli("localhost", "root", "", "records");
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Ensure user is logged in
    if (!isset($_SESSION['user_id'])) {
        die("You must be logged in to update security settings.");
    }
    $user_id = $_SESSION['user_id'];

    // Hash the password
    $hashed_password = password_hash($password, PASSWORD_BCRYPT);

    // Update the user's security settings
    $stmt = $conn->prepare("UPDATE Users SET password = ?, security_question = ?, security_answer = ? WHERE id = ?");
    $stmt->bind_param("sssi", $hashed_password, $security_question, $security_answer, $user_id);

    if ($stmt->execute()) {
        echo "<script>alert('Security settings updated successfully!'); window.location.href = 'dashboard.html';</script>";
    } else {
        echo "<script>alert('Error updating security settings. Please try again.'); window.history.back();</script>";
    }

    $stmt->close();
    $conn->close();
}
?>
