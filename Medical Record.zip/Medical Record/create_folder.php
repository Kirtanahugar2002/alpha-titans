<?php
// create_folder.php
require 'db.php'; // Include your DB connection file

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $folderName = $_POST['folderName'];
    $userId = 1; // Replace with the authenticated user's ID

    $stmt = $pdo->prepare("INSERT INTO folders (user_id, folder_name) VALUES (?, ?)");
    if ($stmt->execute([$userId, $folderName])) {
        echo json_encode(['status' => 'success', 'message' => "Folder '$folderName' created."]);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Failed to create folder.']);
    }
}
?>
