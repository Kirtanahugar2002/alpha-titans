<?php
$host = 'localhost';       // Database host
$dbname = 'records'; // Database name
$username = 'root';         // Database username (change it accordingly)
$password = '';             // Database password (change it accordingly)

try {
    // Create a PDO instance (connect to the database)
    $conn = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);

    // Set the PDO error mode to exception to catch any errors
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

} catch (PDOException $e) {
    // Catch and handle the exception if the connection fails
    echo "Connection failed: " . $e->getMessage();
    die(); // Terminate script if connection fails
}
?>
